<?php $__env->startSection('title'); ?>
    <title><?php echo e($data->setting->store_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main>
        <!-- start shop by category -->
        <section class="shop-by-category py-4">
            <div class="container">
                <div class="row d-flex align-items-stretch">
                    <p class="h2 mb-3">تسوق حسب الفئة</p>
                    <?php $__currentLoopData = $data->categories()->main()->active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-x col-6 col-sm-6 col-md-4 col-lg-3 col-xxl-2">
                            <a href="" class="card">
                                <p><?php echo e($category->name); ?></p>
                                <img src="<?php echo e(asset('storage/files/' . ($category->icon ?? 'default.png'))); ?>" alt="solar panel">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!-- end shop by category -->

        <!-- start products -->
        <section class="section-boards py-3">
            <div class="container">
                <div class="row">
                    <div class="clearfix">
                        <p class="h2 mb-3 float-start">قسم سيستم الطاقة الشمسية</p>
                    </div>

                        <?php $__currentLoopData = $data->products()->active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-x col-sm-6 col-md-4 col-lg-3 col-xxl-2">
                            <div class="card-product p-3">
                                <h6 class="card-title"><?php echo e($product->name); ?></h6>
                                <div class="product-contain">
                                    <img src="<?php echo e(asset('storage/files/' . ($product->image ?? 'default.png'))); ?>" alt="image for product">
                                </div>
                                <div class="card-body d-flex justify-content-between align-items-end">
                                    <div>
                                        <button class="btn bi bi-cart btn-cart"></button>
                                        <button class="btn bi bi-heart btn-heart"></button>
                                    </div>
                                    <div>
                                        <del class="d-block">
                                            <?php if($product->price_sale): ?>
                                            <sapn><?php echo e($product->price_sale); ?></span><?php echo e($data->setting->currency->symbol); ?>

                                            <?php endif; ?>
                                        </del>
                                        <span class="d-block">
                                            <sapn><?php echo e($product->price); ?> <?php echo e($data->setting->currency->symbol); ?></span>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>
        <!-- end products -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('store_front.master', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satoor\resources\views/store_front/home.blade.php ENDPATH**/ ?>