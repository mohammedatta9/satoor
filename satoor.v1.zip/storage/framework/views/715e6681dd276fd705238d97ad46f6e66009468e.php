
<?php echo $__env->make('layouts.dash_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <div id="app">
    <div class="main-wrapper">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
            <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="fas fa-search"></i></a></li>
          </ul>
        </div>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown dropdown-list-toggle"><a target="_blank" href=" " class="nav-link nav-link-lg"><i class="fas fa-home"></i> <?php echo e(__('dash.Visit Website')); ?></i></a>

          </li>


          <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
              
              <img alt="image" src=" " class="rounded-circle mr-1">
              
            <div class="d-sm-none d-lg-inline-block">Admin</div></a>
            <div class="dropdown-menu dropdown-menu-right">

              <a href=" " class="dropdown-item has-icon">
                <i class="far fa-user"></i> <?php echo e(__('dash.Profile')); ?>

              </a>
              <div class="dropdown-divider"></div>
              <a href="" class="dropdown-item has-icon text-danger" onclick="event.preventDefault();
              document.getElementById('admin-logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i> <?php echo e(__('dash.Logout')); ?>

              </a>
            
            <form id="admin-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
            


            </div>
          </li>
        </ul>
      </nav>

      <?php echo $__env->yieldContent('dash-content'); ?>



      <footer class="main-footer">
        <div class="footer-left">
           {{}}
        </div>
        <div class="footer-right">
          </div>
      </footer>
    </div>
  </div>

  <?php echo $__env->make('layouts.dash_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\satoor\resources\views/layouts/dash_master.blade.php ENDPATH**/ ?>