<?php $__env->startSection('title'); ?>
<title><?php echo e(__('dash.Create Category')); ?></title>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('dash-content'); ?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1><?php echo e(__('dash.Edit Category')); ?></h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="<?php echo e(route('user.category.index')); ?>"><?php echo e(__('dash.Category List')); ?></a></div>
              <div class="breadcrumb-item"><?php echo e(__('dash.Edit Category')); ?></div>
            </div>
          </div>

          <div class="section-body">
            <a href="<?php echo e(route('user.category.index')); ?>" class="btn btn-primary"><i class="fas fa-list"></i> <?php echo e(__('dash.Category List')); ?></a>
            <div class="row mt-4">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('user.category.update',$category->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">

                                 
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label ><?php echo e(__('user.Icon')); ?><span class="text-danger">*</span></label>
                                        <input type='file' onchange="loadFile_image(icon)" name="icon" id="icon"
                                                class="<?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                style="display:none;"/>
                                        <button id="output_icon" type="button"
                                                onclick="document.getElementById('icon').click();" value="emad"
                                                style="
                                                    width: 150px;
                                                    height: 150px;
                                                    border-radius: 50%;
                                                    background-color: #cecbcb;
                                                    background-image: url(<?php echo e(asset('storage/files/'.($category->icon ?? 'default.png'))); ?>);
                                                    background-repeat: no-repeat;
                                                    background-size: cover;
                                                    background-position: center;
                                                    "/>
                                    </div>
                                </div>
                                <script>
                                var loadFile_image = function (image) {
                                    var image = document.getElementById('output_icon');
                                    var src = URL.createObjectURL(event.target.files[0]);
                                    image.style.backgroundImage = 'url(' + src + ')';
                                };
                                </script>

                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Name')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" id="name" class="form-control"  name="name" value="<?php echo e(old('name',($category->name))); ?>" required maxlength="200">
                                </div>
                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Name_en')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" id="name_en" class="form-control"  name="name_en" value="<?php echo e(old('name_en',($category->name_en))); ?>" required maxlength="200">
                                </div>

                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Main Category')); ?> <span class="text-danger">*</span></label>
                                    <select name="category_id" class="form-control select2" id="category">
                                        <option value="0" <?php echo e($category->category_id == 0 ? 'selected' : ''); ?>><?php echo e(__('dash.main')); ?></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $category->id != $categ->id ): ?>
                                            <option <?php echo e($category->category_id == $categ->id ? 'selected' : ''); ?> value="<?php echo e($categ->id); ?>"><?php echo e($categ->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Status')); ?> <span class="text-danger">*</span></label>
                                    <select name="status" class="form-control">
                                        <option <?php echo e($category->status==1 ? 'selected': ''); ?> value="1"><?php echo e(__('dash.Active')); ?></option>
                                        <option <?php echo e($category->status==0 ? 'selected': ''); ?>  value="0"><?php echo e(__('dash.InActive')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <button class="btn btn-primary"><?php echo e(__('dash.Update')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                  </div>
                </div>
          </div>
        </section>
      </div>

<script>
    (function($) {
        "use strict";
        $(document).ready(function () {
            $("#name").on("focusout",function(e){
                $("#slug").val(convertToSlug($(this).val()));
            })
        });
    })(jQuery);

    function convertToSlug(Text)
        {
            return Text
                .toLowerCase()
                .replace(/[^\w ]+/g,'')
                .replace(/ +/g,'-');
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satoor\resources\views/user/category/edit_category.blade.php ENDPATH**/ ?>