<?php $__env->startSection('title'); ?>
    <title><?php echo e(__('dashashboard')); ?></title>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('dash-content'); ?>
    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1><?php echo e(__('dashSettings')); ?></h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(__('dashDashboard')); ?></a>
                    </div>
                </div>
            </div>

            <div class="section-body">
                <div class="row mt-4">
                    <div class="col">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-3">
                                            <ul class="nav nav-pills flex-column" id="myTab4" role="tablist">


                                                <li class="nav-item border rounded mb-1">
                                                    <a class="nav-link active" id="general-setting-tab" data-toggle="tab"
                                                        href="#generalSettingTab" role="tab"
                                                        aria-controls="generalSettingTab"
                                                        aria-selected="true"><?php echo e(__('dash.General Setting')); ?></a>
                                                </li>

                                                <li class="nav-item border rounded mb-1">
                                                    <a class="nav-link" id="logo-tab" data-toggle="tab" href="#logoTab"
                                                        role="tab" aria-controls="logoTab"
                                                        aria-selected="true"><?php echo e(__('dash.Logo and Favicon')); ?></a>
                                                </li>

                                                <li class="nav-item border rounded mb-1">
                                                    <a class="nav-link" id="recaptcha-tab" data-toggle="tab"
                                                        href="#recaptchaTab" role="tab" aria-controls="recaptchaTab"
                                                        aria-selected="true"><?php echo e(__('dash.Google Recaptcha')); ?></a>
                                                </li>


                                                <li class="nav-item border rounded mb-1">
                                                    <a class="nav-link" id="custom-pagination-tab" data-toggle="tab"
                                                        href="#customPaginationTab" role="tab"
                                                        aria-controls="customPaginationTab"
                                                        aria-selected="true"><?php echo e(__('dash.Custom Pagination')); ?></a>
                                                </li>

                                                <li class="nav-item border rounded mb-1">
                                                    <a class="nav-link" id="social-login-tab" data-toggle="tab"
                                                        href="#socialLoginTab" role="tab" aria-controls="socialLoginTab"
                                                        aria-selected="true"><?php echo e(__('dash.Social Login')); ?></a>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-9">
                                            <div class="border rounded">
                                                <div class="tab-content no-padding" id="settingsContent">

                                                    <div class="tab-pane fade show active" id="generalSettingTab"
                                                        role="tabpanel" aria-labelledby="general-setting-tab">
                                                        <div class="card m-0">
                                                            <div class="card-body">
                                                                <form action="<?php echo e(route('user.update-general-setting')); ?>"
                                                                    method="POST" enctype="multipart/form-data">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PUT'); ?>
                                                                    <div class="row">
                                                                        
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label
                                                                                    for="username"><?php echo e(__('dash.Logo')); ?></label>
                                                                                <input type='file'
                                                                                    onchange="loadFile_image(logo)"
                                                                                    name="logo" id="logo"
                                                                                    class="<?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    style="display:none;" />
                                                                                <button id="output_logo" type="button"
                                                                                    onclick="document.getElementById('logo').click();"
                                                                                    value="emad"
                                                                                    style="
                                                                                width: 150px;
                                                                                height: 150px;
                                                                                border-radius: 50%;
                                                                                background-color: #cecbcb;
                                                                                background-image: url(<?php echo e(asset('storage/files/' . ($setting->store_logo ?? 'default.png'))); ?>);
                                                                                background-repeat: no-repeat;
                                                                                background-size: cover;
                                                                                background-position: center;
                                                                                " />
                                                                            </div>
                                                                        </div>
                                                                        <script>
                                                                            var loadFile_image = function(image) {
                                                                                var image = document.getElementById('output_logo');
                                                                                var src = URL.createObjectURL(event.target.files[0]);
                                                                                image.style.backgroundImage = 'url(' + src + ')';
                                                                            };
                                                                        </script>

                                                                        
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label
                                                                                    for="username"><?php echo e(__('dash.Footer Logo')); ?></label>
                                                                                <input type='file'
                                                                                    onchange="loadFile_image1(footer_logo)"
                                                                                    name="footer_logo" id="footer_logo"
                                                                                    class="<?php $__errorArgs = ['footer_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    style="display:none;" />
                                                                                <button id="output_footer_logo"
                                                                                    type="button"
                                                                                    onclick="document.getElementById('footer_logo').click();"
                                                                                    value="emad"
                                                                                    style="
                                                                                width: 150px;
                                                                                height: 150px;
                                                                                border-radius: 50%;
                                                                                background-color: #cecbcb;
                                                                                background-image: url(<?php echo e(asset('storage/files/' . ($setting->footer_logo ?? 'default.png'))); ?>);
                                                                                background-repeat: no-repeat;
                                                                                background-size: cover;
                                                                                background-position: center;
                                                                                " />
                                                                            </div>
                                                                        </div>
                                                                        <script>
                                                                            var loadFile_image1 = function(image1) {
                                                                                var image1 = document.getElementById('output_footer_logo');
                                                                                var src1 = URL.createObjectURL(event.target.files[0]);
                                                                                image1.style.backgroundImage = 'url(' + src1 + ')';
                                                                            };
                                                                        </script>

                                                                        <div class="col-md-8">
                                                                            <div class="form-group">
                                                                                <label
                                                                                    for=""><?php echo e(__('dash.store_name')); ?></label>
                                                                                <input type="text" name="store_name"
                                                                                    class="form-control"
                                                                                    value="<?php echo e(old('store_name', $setting->store_name ?? '')); ?> ">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                            <div class="form-group">
                                                                                <label
                                                                                    for=""><?php echo e(__('dash.store_name_en')); ?></label>
                                                                                <input type="text" name="store_name_en"
                                                                                    class="form-control"
                                                                                    value="<?php echo e(old('store_name_en', $setting->store_name_en ?? '')); ?> ">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                            <div class="form-group">
                                                                                <label
                                                                                    for=""><?php echo e(__('dash.Default Currency ')); ?></label>
                                                                                <select name="currency_id" id=""
                                                                                    class="form-control select2">
                                                                                    <option value="">
                                                                                        <?php echo e(__('dash.Select Default Currency')); ?>

                                                                                    </option>
                                                                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option
                                                                                            <?php echo e(isset($setting->currency_id) && $setting->currency_id == $currency->id ? 'selected' : ''); ?>

                                                                                            value="<?php echo e($currency->id); ?>">
                                                                                            <?php echo e($currency->symbol); ?> :
                                                                                            <?php echo e($currency->name); ?>

                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                            <div class="form-group">
                                                                                <label
                                                                                    for=""><?php echo e(__('dash.Timezone')); ?></label>
                                                                                <select name="timezone" id=""
                                                                                    class="form-control select2">

                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-8">
                                                                            <div class="form-group">
                                                                                <label for="maintenance_mode"
                                                                                    class="mr-3"><?php echo e(__('dash.Maintenance Mode')); ?></label>
                                                                                <?php if(isset($setting->currency_id) && $setting->maintenance_mode == 1): ?>
                                                                                    <input type="checkbox" checked
                                                                                        name="maintenance_mode"
                                                                                        value="1"
                                                                                        id="maintenance_mode">
                                                                                <?php else: ?>
                                                                                    <input type="checkbox"
                                                                                        name="maintenance_mode"
                                                                                        value="1"
                                                                                        id="maintenance_mode">
                                                                                <?php endif; ?>

                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-8">

                                                                            <button class="btn btn-primary"
                                                                                type="submit"><?php echo e(__('dash.Update')); ?></button>
                                                                        </div>

                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="tab-pane fade" id="logoTab" role="tabpanel"
                                                        aria-labelledby="logo-tab">
                                                        <div class="card m-0">
                                                            <div class="card-body">
                                                                <form action=" " method="POST"
                                                                    enctype="multipart/form-data">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PUT'); ?>



                                                                    <button
                                                                        class="btn btn-primary"><?php echo e(__('dash.Update')); ?></button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satoor\resources\views/user/setting.blade.php ENDPATH**/ ?>