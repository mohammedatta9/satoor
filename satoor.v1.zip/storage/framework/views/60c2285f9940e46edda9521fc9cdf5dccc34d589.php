<?php $__env->startSection('title'); ?>
<title><?php echo e(__('dash.Create Category')); ?></title>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('dash-content'); ?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1><?php echo e(__('dash.Create Category')); ?></h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="<?php echo e(route('user.category.index')); ?>"><?php echo e(__('dash.Category List')); ?></a></div>
              <div class="breadcrumb-item"><?php echo e(__('dash.Create Category')); ?></div>
            </div>
          </div>

          <div class="section-body">
            <a href="<?php echo e(route('user.category.index')); ?>" class="btn btn-primary"><i class="fas fa-list"></i> <?php echo e(__('dash.Category List')); ?></a>
            <div class="row mt-4">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('user.category.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label ><?php echo e(__('dash.Icon')); ?> <span class="text-danger">*</span></label>
                                        <input type='file' onchange="loadFile_image(icon)" name="icon" id="icon"
                                                class="<?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                style="display:none;"/>
                                        <button id="output_icon" type="button"
                                                onclick="document.getElementById('icon').click();" value="emad"
                                                style="
                                                    width: 150px;
                                                    height: 150px;
                                                    border-radius: 5%;
                                                    background-color: #cecbcb;
                                                    background-image: url(<?php echo e(asset('storage/file-upload.jpg' )); ?>);
                                                    background-repeat: no-repeat;
                                                    background-size: cover;
                                                    background-position: center;
                                                    "/>
                                    </div>
                                </div>
                                <script>
                                var loadFile_image = function (image) {
                                    var image = document.getElementById('output_icon');
                                    var src = URL.createObjectURL(event.target.files[0]);
                                    image.style.backgroundImage = 'url(' + src + ')';
                                };
                                </script>

                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Name')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" id="name" class="form-control"  name="name" maxlength="200" required>
                                </div>
                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Name_En')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" id="name_en" class="form-control"  name="name_en" maxlength="200" required>
                                </div>
                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Main Category')); ?> <span class="text-danger">*</span></label>
                                    <select name="category_id" class="form-control select2" id="category" required>
                                        <option value="0"><?php echo e(__('dash.main')); ?></option>
                                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-12">
                                    <label><?php echo e(__('dash.Status')); ?> <span class="text-danger">*</span></label>
                                    <select name="status" class="form-control">
                                        <option value="1"><?php echo e(__('dash.Active')); ?></option>
                                        <option value="0"><?php echo e(__('dash.InActive')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <button class="btn btn-primary"><?php echo e(__('dash.Save')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                  </div>
                </div>
          </div>
        </section>
      </div>

<script>
    (function($) {
        "use strict";
        $(document).ready(function () {
            $("#name").on("focusout",function(e){
                $("#slug").val(convertToSlug($(this).val()));
            })
        });
    })(jQuery);

    function convertToSlug(Text)
        {
            return Text
                .toLowerCase()
                .replace(/[^\w ]+/g,'')
                .replace(/ +/g,'-');
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satoor\resources\views/user/category/create_category.blade.php ENDPATH**/ ?>