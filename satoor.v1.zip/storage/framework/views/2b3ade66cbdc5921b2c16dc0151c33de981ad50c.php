<?php $__env->startSection('title'); ?>
<title><?php echo e(__('dash.Dashboard')); ?></title>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('dash-content'); ?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1><?php echo e(__('dash.Products')); ?></h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(__('dash.Dashboard')); ?></a></div>
              <div class="breadcrumb-item"><?php echo e(__('dash.Products')); ?></div>
            </div>
          </div>

          <div class="section-body">
            <a href="<?php echo e(route('user.product.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> <?php echo e(__('dash.Add New')); ?></a>
            <div class="row mt-4">
                <div class="col">
                  <div class="card">
                    <div class="card-body">
                      <div class="table-responsive table-invoice">
                        <table class="table table-striped" id="dataTable">
                            <thead>
                                <tr>
                                    <th ><?php echo e(__('dash.SN')); ?></th>
                                    <th ><?php echo e(__('dash.Name')); ?></th>
                                    <th ><?php echo e(__('dash.Icon')); ?></th>
                                    <th ><?php echo e(__('dash.Total Sale')); ?></th>
                                    <th ><?php echo e(__('dash.Status')); ?></th>
                                    <th ><?php echo e(__('dash.Action')); ?></th>
                                  </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$index); ?></td>
                                        <td><a href="<?php echo e(route('user.product.edit',$product->id)); ?>"><?php echo e($product->name); ?></a></td>

                                        <td> <img src="<?php echo e(asset('storage/files/'.($product->image))); ?>" width="80px" alt="<?php echo e($product->name); ?>"></td>
                                        <td> </td>
                                        <td>
                                            <?php if($product->status == 1): ?>
                                                <span class="badge badge-success"><?php echo e(__('dash.Active')); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-danger"><?php echo e(__('dash.Inactive')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                        <a href="<?php echo e(route('user.product.edit',$product->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit" aria-hidden="true"></i></a>

                                        <a href="javascript:;" data-toggle="modal" data-target="#deleteModal" class="btn btn-danger btn-sm" onclick="deleteData(<?php echo e($product->id); ?>)"><i class="fa fa-trash" aria-hidden="true"></i></a>


                                        </td>
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
          </div>
        </section>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="canNotDeleteModal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
          <div class="modal-dialog" role="document">
              <div class="modal-content">
                        <div class="modal-body">
                            <?php echo e(__('dash.You can not delete this product. Because there are one or more order has been created in this product.')); ?>

                        </div>

                  <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(__('dash.Close')); ?></button>
                  </div>
              </div>
          </div>
      </div>
<script>
    "use strict";
    function deleteData(id){
        $("#deleteForm").attr("action",'<?php echo e(url("user/product/")); ?>'+"/"+id)
    }
    function changeProductStatus(id){
        var isDemo = "<?php echo e(env('APP_VERSION')); ?>"
        if(isDemo == 0){
            toastr.error('This Is Demo Version. You Can Not Change Anything');
            return;
        }
        $.ajax({
            type:"put",
            data: { _token : '<?php echo e(csrf_token()); ?>' },
            url:"<?php echo e(url('/user/product-status/')); ?>"+"/"+id,
            success:function(response){
                toastr.success(response)
            },
            error:function(err){
                console.log(err);

            }
        })
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\satoor\resources\views/user/product/index.blade.php ENDPATH**/ ?>