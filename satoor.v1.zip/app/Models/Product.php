<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;


    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }


    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }

    public function colors()
    {
        return $this->hasMany(Product_color::class);
    }
    public function sizes()
    {
        return $this->hasMany(Product_size::class);
    }
    public function images()
    {
        return $this->hasMany(Product_image::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }

}
