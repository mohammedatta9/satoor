<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\User\SettingController as UserSettingController ;
use App\Http\Controllers\User\CategoryController as UserCategoryController;
use App\Http\Controllers\User\ProductController as UserProductController;
use App\Http\Controllers\Front\FrontController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

//admin routes
Route::group(['as'=> 'admin.', 'prefix' => 'admin', 'middleware' => ['auth', 'role:admin']],function () {
    Route::get('/dashboard',[AdminController::class,'dashboard'])->name('dashboard');

});


//user routes
Route::group(['as'=> 'user.',   'middleware' => ['auth', 'role:user']],function () {
    Route::get('/dashboard',[UserController::class,'dashboard'])->name('dashboard');

    // category
    Route::resource('category', UserCategoryController::class);
    Route::put('category-status/{id}', [UserCategoryController::class,'changeStatus'])->name('category.status');

    // product
    Route::resource('product', UserProductController::class);
    Route::put('productImage_delete/{id}', [UserProductController::class,'productImage_delete'])->name('productImage_delete');

    Route::get('general-setting',[UserSettingController::class,'index'])->name('general-setting');
    Route::put('update-general-setting',[UserSettingController::class,'updateGeneralSetting'])->name('update-general-setting');

});

Route::get('/{slug}', [FrontController::class, 'home'])->name('store.show');
